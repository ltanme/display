
INSERT INTO `gf_category` VALUES (16,'characters', '', 0, 1, '一年级上册', 0, NULL, NULL, NULL, '2020-06-04 00:04:37', '2020-06-04 00:04:41');
INSERT INTO `gf_category` VALUES (17,'characters', '', 0, 1, '一年级下册', 0, NULL, NULL, NULL, '2020-06-04 00:04:37', '2020-06-04 00:04:41');
INSERT INTO `gf_category` VALUES (18,'characters', '', 0, 1, '二年级上册', 0, NULL, NULL, NULL, '2020-06-04 00:04:37', '2020-06-04 00:04:41');
INSERT INTO `gf_category` VALUES (19,'characters', '', 0, 1, '二年级下册', 0, NULL, NULL, NULL, '2020-06-04 00:04:37', '2020-06-04 00:04:41');
